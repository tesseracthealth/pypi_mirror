from bumpversion.cli import main


main()
